#include <string.h>
#ifdef Read
#define Read

 char * Read();
 char * Read2();
#endif
